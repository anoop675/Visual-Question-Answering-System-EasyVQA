from .easy_vqa import get_train_questions, get_test_questions, get_train_image_paths, get_test_image_paths, get_answers
