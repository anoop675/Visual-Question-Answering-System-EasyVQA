from enum import Enum

class Shape(Enum):
  RECTANGLE = 1
  CIRCLE = 2
  TRIANGLE = 3